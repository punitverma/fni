<?php
declare(strict_types=1);


namespace App\Controller;
use Cake\Datasource\ConnectionManager;
/**
 * Members Controller
 *
 * @property \App\Model\Table\MembersTable $Members
 *
 * @method \App\Model\Entity\Member[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class MembersController extends AppController
{

    public function beforeFilter(\Cake\Event\EventInterface $event)
{
parent::beforeFilter($event);
// configure the login action to don't require authentication, preventing
// the infinite redirect loop issue
$this->Authentication->addUnauthenticatedActions(['add','get','confirm']);
}
    
    /**
     * View method
     *
     * @param string|null $id Member id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    
    public function get($id = null)
    {
        
        $member = $this->Members->find('all',['fields'=>'name'])->where(['id'=>$id]);
        return $this->response->withType('application/json')->withStringBody(json_encode(['result' => $member]));
        
      

    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $this->viewBuilder()->setLayout('landing');
        $member = $this->Members->newEmptyEntity();

        if ($this->request->is('post')) {
            $member = $this->Members->patchEntity($member, $this->request->getData());
            $state_id=$this->request->getData('state_id');

            $member['id']=$this->generateID();
            if($member['membertype_id']!=1){
                $member['gender']='N';
            }
  
            $connection = ConnectionManager::get('default');

            $status='';
            $password='nic123';
            $this->loadModel('Users');
            $user=$this->Users->newEmptyEntity();
            $user['password']=$password;
            $password=$user['password'];

            $connection->execute('CALL sp_addmemeber(?,?,?,?,?,?,?,?,@status,?,?)',[$member['id'],$member['sponsor'],$member['placement'],$member['name'],$member['membertype_id'],$member['mobile'],$member['email'],$password,$member['gender'],$state_id]);
            $status= $connection->query('SELECT @status as status')->fetchAll('assoc');;
            debug($member);
            debug($status);
            die($status[0]['status']);
            if ($status[0]['status']=='Y') {
               // $this->Flash->success(__('The member has been saved.'));
                $this->set('username',$member['id']);
                $this->set('mobile',$member['mobile']);
                //return $this->redirect(['action' => 'confirm']);
                return $this->render('confirm');
            }
            $this->Flash->error(__('The Distributor  could not be saved. Please, try again.'));
        }
        $membertypes = $this->Members->Membertypes->find('list', ['limit' => 200]);
        $this->loadModel('States');
        $states=$this->States->find('list');
        $place=['L'=>'Placement: Left','R'=>'Placement: Right'];
        $genders=['M'=>'Sex :Male','F'=>'Sex :Female','X'=>'Sex :Transgender' ,'N'=>'Sex :N/A'];
 //       $addresses = $this->Members->Addresses->find('list', ['limit' => 200]);
        $this->set(compact('member', 'membertypes','place','states','genders'));
    }

    
    public function generateID(){

        $id="FNI".str_pad(''.rand(1,99999999),8,'0',STR_PAD_LEFT);

        return $id;

    }

    public function genealogy($id=null){
        $this->viewBuilder()->setLayout('member');
        $u = $this->Authentication->getResult()->getData();
        if($id==null)
            $members= $this->genealogy_fetch($u->username);
        else
            $members= $this->genealogy_fetch($id);
        //debug($members);
        $this->set(compact('members'));

    }

    private function genealogy_fetch($id){
        static $i=1;
        $member = $this->Members->get($id);
        
        //debug($member);
        if($member->leftid!=null){
            
            $member['left']=$this->Members->get($member->leftid);//$this->genealogy_fetch($member->leftid);
        }
        if($member->rightid!=null){
            $member['right']=$this->Members->get($member->rightid);//$this->genealogy_fetch($member->rightid);
        }

        return $member;



    }
}
