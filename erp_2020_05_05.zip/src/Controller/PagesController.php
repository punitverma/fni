<?php
declare(strict_types=1);

/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link      https://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   https://opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Http\Exception\ForbiddenException;
use Cake\Http\Exception\NotFoundException;
use Cake\Http\Response;
use Cake\View\Exception\MissingTemplateException;
use Cake\Datasource\Exception\InvalidPrimaryKeyException;
use Cake\Database\Expression\QueryExpression;
/**
 * Static content controller
 *
 * This controller will render views from templates/Pages/
 *
 * @link https://book.cakephp.org/4/en/controllers/pages-controller.html
 */
class PagesController extends AppController
{
    /**
     * Displays a view
     *
     * @param array ...$path Path segments.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Http\Exception\ForbiddenException When a directory traversal attempt.
     * @throws \Cake\View\Exception\MissingTemplateException When the view file could not
     *   be found and in debug mode.
     * @throws \Cake\Http\Exception\NotFoundException When the view file could not
     *   be found and not in debug mode.
     * @throws \Cake\View\Exception\MissingTemplateException In debug mode.
     */
    public function display(...$path): ?Response
    {
        if (!$path) {
            return $this->redirect('/');                                                                                                                                                                                                                                                                                                                           
        }
        if (in_array('..', $path, true) || in_array('.', $path, true)) {
            throw new ForbiddenException();
        }
        $page = $subpage = null;

        if (!empty($path[0])) {
            $page = $path[0];
        }
        if (!empty($path[1])) {
            $subpage = $path[1];
        }
        $this->set(compact('page', 'subpage'));

        try {
           // $this->layout = 'home';
            $this->viewBuilder()->setLayout('landing');

            return $this->render(implode('/', $path));
        } catch (MissingTemplateException $exception) {
            if (Configure::read('debug')) {
                throw $exception;
            }
            throw new NotFoundException();
        }

        return $this->render();
    }
    public function districts($state_id){
        
        $this->loadModel('Districts');
        $result=$this->Districts->find('list')->where(['state_id'=>$state_id]);
                
        return $this->response->withType('application/json')->withStringBody(json_encode(['result' => $result]));
        
    }
    public function ifsc($code){
        $this->loadModel('Banks');
        
        try{
        $result=$this->Banks->find('all')->where(['IFSC'=>$code])->first();
        if($result)
        return $this->response->withType('application/json')->withStringBody(json_encode(['result' => 'ok','bank'=>$result]));
        else
        return $this->response->withType('application/json')->withStringBody(json_encode(['result' => 'error']));
        }
        catch(InvalidPrimaryKeyException  $exception  )
        {
            return $this->response->withType('application/json')->withStringBody(json_encode(['result' => 'error','ex'=>$exception]));
        }
        
        
        
        
    }
    public function getstate($id,$type,$inv_id){
        
        $this->loadModel('States');
        $this->loadModel('Invoices');
        $name='';
        if($type=='P'){
            $this->loadModel('Manufactures');
            $result=$this->Manufactures->find('all',['contain'=>['states']])->select(['states.id','states.name'])->where(['Manufactures.id'=>$id]);
            
            
        }
        else
        if($type=='S'){
            $this->loadModel('Members');
            $result=$this->Members->find('all',['contain'=>['states']])->select(['states.id','states.name'])->where(['Manufactures.id'=>$id]);
        }
        else
        if($type=='O'){
          
            $result=['id'=>20,'name'=>'Jharkhand'];
        }   
        $result= $result->first();
        
        $inv=  ['toid'=>$id,'tostate'=>$result->state->id];
       
        
        $this->Invoices->updateAll($inv,['id'=>$inv_id]);


        return $this->response->withType('application/json')->withStringBody(json_encode(['status'=>'ok','result' => $result]));
        
    }
    function confirm($title,$message){

        $this->set(compact('title','message'));
    }
}
