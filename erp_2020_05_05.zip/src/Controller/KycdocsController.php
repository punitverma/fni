<?php

declare(strict_types=1);

namespace App\Controller;

/**
 * Kycdocs Controller
 *
 * @property \App\Model\Table\KycdocsTable $Kycdocs
 *
 * @method \App\Model\Entity\Kycdoc[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class KycdocsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $this->viewBuilder()->setLayout('member');
        $u = $this->Authentication->getResult()->getData();
        $kyc = $this->Kycdocs->Kycs->find('all')->where(['member_id' => $u->username])->first();

        $kycdoc = $this->Kycdocs->find()->where(['kyc_id' => $kyc->id])->first();

        $uploadData = '';

        if ($this->request->is(['post', 'put'])) {
            $file = $this->request->getData('file');

            if (!empty($file->getClientFilename())) {

                $fileName = $file->getClientFilename();
                $uploadPath = 'd:/tmp/';
                $uploadFile = $uploadPath . $kyc->id;

                if ($file->getSize() >  2 * 1024 * 1024) { //2MB 
                    $this->Flash->error(__('Max File Size is 2 MB'));
                } else {
                    $file->moveTo($uploadFile);


                    $uploadData = $this->Kycdocs->newEmptyEntity();
                    if (!empty($kycdoc)) {
                        $uploadData->id = $kycdoc->id;
                    } else {
                        $uploadData->id = null;
                    }
                    $uploadData->kyc_id = $kyc->id;
                    //$uploadData->kyc_id=$kyc->id;    
                    $uploadData->name = $fileName;
                    $uploadData->path = $uploadPath;


                    if ($this->Kycdocs->save($uploadData)) {

                        $this->Flash->success(__('File has been uploaded and inserted successfully.'));
                        $this->redirect(['controller' => 'kycs', 'action' => 'index']);
                    } else {
                        $this->Flash->error(__('Unable to upload file, please try again.'));
                    }
                    //debug($uploadData);


                }
            } else {
                $this->Flash->error(__('Please choose a file to upload.'));
            }
        }
        $this->set(compact('kyc', 'kycdoc'));
    }
    public function sendFile()
    {
        $this->viewBuilder()->setLayout('member');
        $u = $this->Authentication->getResult()->getData();
        $kyc = $this->Kycdocs->Kycs->find('all')->where(['member_id' => $u->username])->first();

        $kycdoc = $this->Kycdocs->find()->where(['kyc_id' => $kyc->id])->first();

        
        $response = $this->response->withFile($kycdoc->path.'/'.$kycdoc->kyc_id,['download' => true, 'name' => $kycdoc->name]);
        // Return the response to prevent controller from trying to render
        // a view.
        return $response;
    }
}
