<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Member Entity
 *
 * @property string $id
 * @property int $membertype_id
 * @property string $sponsor
 * @property string $parent
 * @property string $placement
 * @property string $name
 * @property string $gender
 * @property string $adddetails
 * @property string $mobile
 * @property string $email
 * @property int $address_id
 * @property string $kyc
 * @property string $active
 * @property string|null $leftid
 * @property string|null $rightid
 * @property \Cake\I18n\FrozenTime $cr_tm
 * @property \Cake\I18n\FrozenTime|null $created
 * @property \Cake\I18n\FrozenTime|null $modified
 *
 * @property \App\Model\Entity\Membertype $membertype
 * @property \App\Model\Entity\Address $address
 * @property \App\Model\Entity\Kyc[] $kycs
 * @property \App\Model\Entity\Ledger[] $ledgers
 * @property \App\Model\Entity\Transcation[] $transcations
 */
class Member extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'membertype_id' => true,
        'sponsor' => true,
        'parent' => true,
        'placement' => true,
        'name' => true,
        'gender' => true,
        'adddetails' => true,
        'mobile' => true,
        'email' => true,
        'address_id' => true,
        'kyc' => true,
        'active' => true,
        'leftid' => true,
        'rightid' => true,
        'cr_tm' => true,
        'created' => true,
        'modified' => true,
        'membertype' => true,
        'address' => true,
        'kycs' => true,
        'ledgers' => true,
        'transcations' => true,
    ];
}
