<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Invoice Entity
 *
 * @property int $id
 * @property string $trtype
 * @property string $type
 * @property string $receipt
 * @property \Cake\I18n\FrozenDate $date
 * @property string $fromid
 * @property string $fromname
 * @property int $fromstate
 * @property string $toid
 * @property string $toname
 * @property int $tostate
 * @property float $amount
 * @property int $points
 * @property string|null $ref
 * @property \Cake\I18n\FrozenTime $dt_tm
 * @property \Cake\I18n\FrozenTime|null $created
 * @property \Cake\I18n\FrozenTime|null $modified
 *
 * @property \App\Model\Entity\Invoicedetail[] $invoicedetails
 * @property \App\Model\Entity\Transcation[] $transcations
 */
class Invoice extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'trtype' => true,
        'type' => true,
        'receipt' => true,
        'date' => true,
        'fromid' => true,
        'fromname' => true,
        'fromstate' => true,
        'toid' => true,
        'toname' => true,
        'tostate' => true,
        'amount' => true,
        'points' => true,
        'ref' => true,
        'dt_tm' => true,
        'created' => true,
        'modified' => true,
        'invoicedetails' => true,
        'transcations' => true,
    ];
}
