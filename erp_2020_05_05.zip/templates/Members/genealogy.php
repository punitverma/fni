<?php
function generate_genealogy($ms)
{
    $out = "<ul>";
    $out .= "<li>";
    $out .= '<a href="#">' . $ms['id'] . '</a>';
    $out .= "<ul>";
    $out .= "<li>";

    

    if($ms['leftid']!=null)
        {
            $out .= "<ul>";
            $out .= "<li>";
            $out .= '<a href="#">' . $ms['left']->id . '</a>';
            $out .= "<ul>";
            $out .= "<li>";
            $out .= '<a href="#">' . ($ms['left']->leftid ==null ? "N/A" :$ms['left']->leftid ) . '</a>';
            $out .= "</li>";
            $out .= "<li>";
            $out .= '<a href="#">' . ($ms['left']->rightid ==null ? "N/A" :$ms['left']->rightid ) . '</a>';
            $out .= "</li>";
            $out .= "</ul>";

        }
    else
        $out .= '<a href="#">' . ( $ms['leftid']==null ? "N/A" : $ms['leftid']) . '</a>';

    $out .= "</li>";
    
    $out .= "<li>";
    
    if($ms['rightid']!=null)
        {
            $out .= "<ul>";
            $out .= "<li>";
            $out .= '<a href="#">' . $ms['right']->id . '</a>';
            $out .= "<ul>";
            $out .= "<li>";
            $out .= '<a href="#">' . ($ms['right']->leftid ==null ? "N/A" :$ms['right']->leftid ) . '</a>';
            $out .= "</li>";
            $out .= "<li>";
            $out .= '<a href="#">' . ($ms['right']->rightid ==null ? "N/A" :$ms['right']->rightid ) . '</a>';
            $out .= "</li>";
            $out .= "</ul>";

        }
    else
    $out .= '<a href="#">' . ($ms['rightid']==null ? "N/A" : $ms['rightid']) . '</a>';

    $out .= "</li>";
    $out .= "</ul>";

    $out .= "</li>";
    $out .= "</ul>";


    return $out;
}
//debug($members);
//debug(generate_genealogy($members) );
//die();
?>
<!--Main layout-->
<main>
    <div class="container">

        <!--Section: Main info-->
        <section class="mt-5 pt-5 wow">
            <div class="row">
                <div class="col-md-12 col-xl-10 col-sm-12 mb-4 mt-5">

                    <div class="card">
                        <div class="card-header info">
                            Genealogy
                        </div>
                        <div class="card-body">
                            <!--
                            We will create a family tree using just CSS(3)
                            The markup will be simple nested lists
                            -->
                            <div class="tree">
                                <?= generate_genealogy($members) ?>
    
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </section>
    </div>
</main>
<script>
    $(function() {

        $(".tree a").click(function() {
           if(this.text !='N/A') 
           document.location="/members/genealogy/"+this.text;
        });



        var lb = $("#sponsor_id").find('label');
        $("#sponsor").blur(function() {

            if ($("#sponsor").val().length >= 10) {
                $.ajax('/findmember/' + $("#sponsor").val(), {
                    type: 'GET', // http method
                    //data: { myData: 'This is my data.' },  // data to submit
                    success: function(data, status, xhr) {
                        if (data['result'][0] == null)
                            lb.html("Sponser Id : " + "<span color='blue'>" + "Not Match" + "</span>")
                        else
                            lb.html("Sponser Id : " + "<span color='blue'>" + data['result'][0]['name'] + "</span>")
                    },
                    error: function(jqXhr, textStatus, errorMessage) {
                        lb.html("Sponser Id : " + "<span color='red'>" + "Error" + "</span>")
                    }
                });
            }
        });

    });
</script>