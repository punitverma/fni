<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Invoice[]|\Cake\Collection\CollectionInterface $invoices

 */
$v = array('P' => 'Purchase', 'S' => 'Sale', 'O' => 'Order','I'=>'Invoice');
?>
<div class="invoices index content">
    <?= $this->Html->link(__('New Invoice'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= $v[$type] ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    
                    <th><?= $this->Paginator->sort('receipt') ?></th>
                    <th><?= $this->Paginator->sort('date') ?></th>
                    <th><?= $this->Paginator->sort('fromid') ?></th>
                    <th><?= $this->Paginator->sort('fromname') ?></th>
                    <th><?= $this->Paginator->sort('toid') ?></th>
                    <th><?= $this->Paginator->sort('toname') ?></th>
                    <th><?= $this->Paginator->sort('amount') ?></th>
                    <th><?= $this->Paginator->sort('ref') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($invoices as $invoice): ?>
                <tr>
                    <td><?= h($invoice->receipt) ?></td>
                    <td><?= h($invoice->date) ?></td>
                    <td><?= h($invoice->fromid) ?></td>
                    <td><?= h($invoice->fromname) ?></td>
                    <td><?= h($invoice->toid) ?></td>
                    <td><?= h($invoice->toname) ?></td>
                    <td><?= h($invoice->ref) ?></td>
                    <td><?= $this->Number->format($invoice->amount) ?></td>

                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $invoice->id]) ?>
                        <?php if($type=='I') {?>
                        <?= $this->Html->link(__('Invoice'), ['controller'=>'/','action' => 'invoice',$invoice->receipt]) ?>
                        <?php } ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
