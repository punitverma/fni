<?php

//die();
?>
<!--Main layout-->
<main>
    <div class="container">

        <!--Section: Main info-->
        <section class="mt-5 pt-5 wow">
            <div class="row">
                <div class="col-md-12 col-xl-10 col-sm-12 mb-4 mt-5">

                    <div class="card">
                        <div class="card-header info">
                            KYC (Know Your Customer)
                        </div>
                        <div class="card-body">
                        <?= $this->Form->create($kyc) ?>
                            <div class="col-md-6 col-sm-12">
                                <div class="md-form">
                                    <?= $this->Form->control('pan', ['label' => 'PAN Card No.', 'class' => 'form-control']); ?>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="md-form">
                                    <?= $this->Form->control('name', ['label' => 'Name of Acc Holder.', 'class' => 'form-control']); ?>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="md-form">
                                    <?= $this->Form->control('ifsc', ['label' => 'IFSC Code', 'class' => 'form-control']); ?>
                                    Bank : <span id="bank"> </span> 
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="md-form">
                                    <?= $this->Form->control('accno', ['label' => 'Bank Account No', 'class' => 'form-control']); ?>
                                </div>
                            </div>
                            <div class="row">
                            <div class="col-2">
                                 <a href="/kycdocs" class="button btn" >Upload Document</a>
                            </div>
                            <div class="col-2">
                               <a href="/kycdocs/sendFile" class="button btn <?= $kyc->doc ? 'disabled' : '' ?>" >View Document</a>
                               
                            </div>
                        </div>

                            
                        </div>
                        <div class="col-md-6 col-sm-10">
                        <?php if($kyc->approveby==null && $kyc->approveon==null){ ?>
                        <?= $this->Form->button(__('Submit'),['id'=>'btnSave','class' => 'form-control primary','disabled'=>true]) ?>
                        <?php } ?>
                        </div>
                        
                        <?= $this->Form->end() ?>

                    </div>
                </div>
                    
            </div>
/
        </section>
    </div>
</main>
<script>
$(function() {

$("#ifsc").blur(function(){
    ifsc($("#btnSave").prop('disabled',true));
    if($("#ifsc").val().length>=8){
        ifsc($("#ifsc").val());     
    }
});

});
function ifsc(code){
    var lb=$("#bank");
    $("#btnSave").prop('disabled',true);

    $.ajax('/ifsc/'+code, {
        type: 'GET',  
        success: function (data, status, xhr) {
            if(data['result']=='ok'){
                $("#btnSave").prop('disabled',false);
            
                lb.html(data['bank']['BANK']+" Branch :"+ data['bank']['BRANCH']);
            }
            else
            if(data['result']=='error'){
                lb.html("Not Found")
            }
        },
        error: function (jqXhr, textStatus, errorMessage) {
            lb.html("N/A")
        }
        });
}
</script>