<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Invoicedetail Entity
 *
 * @property int $id
 * @property int $invoice_id
 * @property int $item_id
 * @property string $itemname
 * @property string $itemcat
 * @property string $hsn
 * @property int $price
 * @property int $points
 * @property int $qty
 * @property int $sgst_p
 * @property float $sgst_a
 * @property int $cgst_p
 * @property float $cgst_a
 * @property int $igst_p
 * @property float $igst_a
 * @property float $amount
 *
 * @property \App\Model\Entity\Invoice $invoice
 * @property \App\Model\Entity\Item $item
 */
class Invoicedetail extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'invoice_id' => true,
        'item_id' => true,
        'itemname' => true,
        'itemcat' => true,
        'hsn' => true,
        'price' => true,
        'points' => true,
        'qty' => true,
        'sgst_p' => true,
        'sgst_a' => true,
        'cgst_p' => true,
        'cgst_a' => true,
        'igst_p' => true,
        'igst_a' => true,
        'amount' => true,
        'invoice' => true,
        'item' => true,
    ];
}
