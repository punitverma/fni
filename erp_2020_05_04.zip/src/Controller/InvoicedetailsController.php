<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Invoicedetails Controller
 *
 * @property \App\Model\Table\InvoicedetailsTable $Invoicedetails
 *
 * @method \App\Model\Entity\Invoicedetail[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class InvoicedetailsController extends AppController
{
    public function add()
    {

        $this->loadModel('Invoices');
        $invoicedetail = $this->Invoicedetails->newEmptyEntity();
        
        if ($this->request->is('post') && $this->request->is('ajax'))  {
            $invoicedetail = $this->Invoicedetails->patchEntity($invoicedetail, $this->request->getData());
            $invoice=$this->Invoices->get($invoicedetail->invoice_id);

            if($invoice->trtype!='D')
            return $this->response->withType('application/json')->withStringBody(json_encode(['result' => 'error']));
            else
            if( empty( $invoice->toid) || $invoice->toid=='' )
            return $this->response->withType('application/json')->withStringBody(json_encode(['result' => '-Select-']));
            

           
            
            $item=$this->Invoicedetails->Items->get($invoicedetail->item_id, [
                'contain' => ['Itemcats']]);

            
            $qty=$invoicedetail->qty;
            if($invoice->type=='P'){
                $price=$item->purchaseprice;
                $invoicedetail->amount=($price + $price * $item->tax/100) * $qty;
            }
            else{
                $price=$item->saleprice;
                $invoicedetail->amount=$item->dp*$qty;
            }
            $invoicedetail->itemname=$item->name;
            $invoicedetail->points=$item->points*$qty;
            $invoicedetail->hsn=$item->hsn;
            $invoicedetail->itemcat=$item->itemcat->name;
           
            $invoicedetail->price=$price;
            
            if($invoice->tostate<>$invoice->fromstate){
                $invoicedetail->igst_p=$item->tax;
                $invoicedetail->igst_a= round( $item->tax * $price * $qty /100,2);
            }else{
                $invoicedetail->sgst_p=$item->tax/2;
                $invoicedetail->sgst_a=round($item->tax * $price * $qty/200,2);

                $invoicedetail->cgst_p=$item->tax/2;
                $invoicedetail->cgst_a=round($item->tax * $price * $qty/200,2);
            }
            
           
           
            if ($invoice->trtype=='D' && $this->Invoicedetails->save($invoicedetail)) {
                
                return $this->response->withType('application/json')->withStringBody(json_encode(['result' => 'ok','data'=>$invoicedetail]));
            }
            
        }
        return $this->response->withType('application/json')->withStringBody(json_encode(['result' => 'error']));
    }

    /**
     * Delete method
     *
     * @param string|null $id Invoicedetail id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id ,$invoice_id)
    {

        
        $this->request->allowMethod(['get', 'delete']);
        $invoicedetail = $this->Invoicedetails->get($id, [
            'contain' => ['Invoices'],
        ]);
   
        if($this->request->is('ajax') && $invoicedetail->invoice_id==$invoice_id && $invoicedetail->invoice->trtype=='D') {
            if ($this->Invoicedetails->delete($invoicedetail)) {
                return $this->response->withType('application/json')->withStringBody(json_encode(['result' => 'ok','amount'=>$invoicedetail->price * $invoicedetail->qty]));
                } 
        }
        return $this->response->withType('application/json')->withStringBody(json_encode(['result' => 'error']));

     
    }
}
