<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Frenchies Controller
 *
 * @property \App\Model\Table\FrenchiesTable $Frenchies
 *
 * @method \App\Model\Entity\Frenchy[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class FrenchiesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index($id=null)
    {
        $this->loadComponent('Authentication.Authentication');
        $this->paginate = [
            'contain' => ['States','Districts','Frenchietypes'],
        ];
        $this->loadModel('Users');
        
        $state_id=0;
        $this->viewBuilder()->setLayout('admin');
        $user=null;

        $u= $this->Authentication->getResult()->getData();
        $max_id=0;

        

        if(is_null($id)){
            $item = $this->Frenchies->newEmptyEntity();
            $item->id=$this->generateID();

            $user=$this->Users->newEmptyEntity();
            $user->username=$item->id;
            $user->password='nic123';
            $user->role_id=4;
            $user->refid=$item->id;
            

        }
        else{
            $item=$this->Frenchies->get($id, ['contain' => ['States','Districts','Frenchietypes']   ]);
            $state_id=$item->state_id;
        }
            $states = $this->Frenchies->States->find('list', ['limit' => 200]);
            $districts = $this->Frenchies->Districts->find('list')->where(['state_id'=>$state_id]);
            
            if($u->role_id==2){
            $frenchietypes=$this->Frenchies->Frenchietypes->find()->combine('scope', 'name');
            $items = $this->paginate($this->Frenchies);
            }
            else
            if($u->role_id==4){
                $f=$this->Frenchies->get($u->username);
                $items = $this->paginate($this->Frenchies,['conditions'=>['sponsor '=>$u->username]]);
                $frenchietypes=$this->Frenchies->Frenchietypes->find('all')->where(['scope > '=>$f->frenchietype_id])->combine('scope', 'name');// select(['id'=> 'scope','name'])->toArray();
                $max_id=$f->frenchietype_id;
            }
            else{
                return ;
            }


        if ($this->request->is('post') || $this->request->is('put')) {
            
            $item = $this->Frenchies->patchEntity($item, $this->request->getData());


            if($u->role_id==4){
                $item->sponsor=$u->username;
            }
            
            if($item->frenchietype_id==1){
                $item->sponsor=null;
            }
            //die($item);

            if($item->frenchietype_id >$max_id)
            if ($this->Frenchies->save($item)) {

                if(!is_null($user)){
                    $this->Users->save($user);
                }
                $this->Flash->success(__('The Frenchie has been saved.'));
                $item = $this->Frenchies->newEmptyEntity();
                $this->set(compact('items','item','states','districts'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The Frenchie could not be saved. Please, try again.'));
        }

        $this->set(compact('items','item','states','districts','frenchietypes','max_id'));
    }


    

    public function generateID(){

        $id="FNIF".str_pad(''.rand(1,999999),6,'0',STR_PAD_LEFT);

        return $id;

    }

    public function get($id = null)
    {
       
        $member = $this->Frenchies->find('all',['fields'=>'name'])->where(['id'=>$id]);
        return $this->response->withType('application/json')->withStringBody(json_encode(['result' => $member]));
        
       

    }
}
