<?php

declare(strict_types=1);

namespace App\Controller;

use function PHPSTORM_META\type;

/**
 * Invoices Controller
 *
 * @property \App\Model\Table\InvoicesTable $Invoices
 *
 * @method \App\Model\Entity\Invoice[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class InvoicesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index($type)
    {
        $u = $this->Authentication->getResult()->getData();
        $conditions=[];
        if($type=='P' || $type=='S' || $type=='O'){
            $conditions=['type'=>$type, 'trtype !='=>'D','fromid'=> $u->username];
        }
        else
        if($type=='I')
        {
            $conditions=['type'=>'O','trtype !='=>'D','toid'=> $u->username];
        }


        $invoices = $this->paginate($this->Invoices,['conditions'=>$conditions]);

        $this->set(compact('invoices','type'));
        $this->viewBuilder()->setLayout('admin');
    }

    /**
     * View method
     *
     * @param string|null $id Invoice id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $this->viewBuilder()->setLayout('print');
        $this->loadModel('States');
        
        $states = $this->States->find('list');
        $invoice = $this->Invoices->find('all',[
            'contain' => ['Invoicedetails'], 'conditions'=>['receipt' =>$id ,'trtype !=' => 'D']
        ])->first();
        //$inv = $this->Invoices->find('all')->where(['ref' => $ref, 'type' => $type])->contain(['invoicedetails'])->first();

        $this->set('invoice', $invoice);
        $this->set('states', $states->toArray());
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add($type=null,$ref=null)
    {
        
        $this->viewBuilder()->setLayout('admin');
        $invoice = $this->Invoices->newEmptyEntity();
        $invoicedetail = $this->Invoices->Invoicedetails->newEmptyEntity();
        $u = $this->Authentication->getResult()->getData();

        $tolist = null;
        $this->loadModel('States');
        $this->loadModel('Items');
        $states = $this->States->find('list');
        $items = $this->Items->find('list');

        
        if ($type == 'I') {

            $inv = $this->Invoices->find('all')->where(['ref' => $ref, 'type' => $type])->contain(['invoicedetails'])->first();
        } else {
            $inv = $this->Invoices->find('all')->where(['fromid' => $u->username, 'trtype' => 'D', 'type' => $type])->contain(['invoicedetails'])->first();
        }

        if($type=='P'){
            $this->loadModel('Manufactures');
            $tolist = $this->Manufactures->find('list');
        }
                


            if (empty($inv)) {


                if ($type == 'P' || $type=='I') {

                    $invoice->type = $type;
                    $invoice->trtype = 'D';
                    $invoice->ref=$ref;
                    $invoice->fromid = $u->username;
                    $invoice->fromname = 'Company';
                    $invoice->fromstate = 20; //Jharkhand
    
                    
                    if($type=='I'){
                       $inv= $this->Invoices->find('all')->where(['receipt' => $ref, 'type' => 'O'])->first();
                       $invoice->toid=$inv->fromid;
                       $invoice->toname=$inv->fromname;
                       $invoice->tostate=$inv->fromstate;
                    }
                }
                if ($type == 'O' && $u->role_id == 4) {
                    $this->loadModel('Frenchies');
                    $f = $this->Frenchies->get($u->username);
    
                    $invoice->type = $type;
                    $invoice->trtype = 'D';
                    
                    $invoice->fromid = $f->id;
                    $invoice->fromname = $f->name;
                    $invoice->fromstate = $f->state_id;
    
                    $invoice->toid = $u->username;
                    $invoice->toname = 'Company';
                    $invoice->tostate = 20; //Jharkhand
                    //$this->loadModel('Manufactures');
                    //$tolist=$this->Manufactures->find('list');
    
    
                }
                

                $invoice->id = null;
                $invoice->receipt=$this->generateID($type);
                
                $this->Invoices->save($invoice);
                $invoice['invoicedetails']=$this->Invoices->Invoicedetails->find()->where(['invoice_id'=>$invoice->id]);
            } else {
                $invoice = $inv;
            }
        
        $this->set('states', $states->toArray());
        $this->set('items', $items);

        $this->set('invoice_id', $invoice->id);
        $this->set(compact('invoice', 'type', 'tolist', 'invoicedetail'));
    }

    
    public function save($id = null)
    {
        $invoice = $this->Invoices->newEmptyEntity();
        $u = $this->Authentication->getResult()->getData();
        $inv = $this->Invoices->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $invoice = $this->Invoices->patchEntity($invoice, $this->request->getData());
            
            $inv->date = $invoice->date;
            $inv->ref = $invoice->ref;


            if($inv->type=='P')
                $inv->receipt = $invoice->receipt;

            if ($inv->type == 'O') {
                $invoice->toid = 'admin';
                $invoice->toname = 'Company';
                $invoice->tostate = 20;
            }

            if($inv->type!='I'){
         //   $inv->toid = $invoice->toid;
            $inv->toname = $invoice->toname;
          //  $inv->tostate = $invoice->tostate;
            }

            if ($inv->trtype == 'D') {
                if ($u->role_id == 2)     $inv->trtype = 'C';
                if ($u->role_id == 4)     $inv->trtype = 'F';
              //  debug($inv);
                if ($this->Invoices->save($inv)) {
                    return $this->response->withType('application/json')->withStringBody(json_encode(['result' => 'ok', 'receipt' => $inv->receipt]));
                }
            }
        }
        return $this->response->withType('application/json')->withStringBody(json_encode(['result' => 'error', 'receipt' => $inv->receipt]));
    }

    public function generateID($type){

        $id=$type . date("Y") . date("m") . date("d") .str_pad(''.rand(1,999999),6,'0',STR_PAD_LEFT);

        return $id;

    }
}
