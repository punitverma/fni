<?php

declare(strict_types=1);

namespace App\Controller;

use Cake\Http\Session;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{

    public function beforeFilter(\Cake\Event\EventInterface $event)
    {
        parent::beforeFilter($event);
        // configure the login action to don't require authentication, preventing
        // the infinite redirect loop issue
        $this->Authentication->addUnauthenticatedActions(['login','logout','forgotpassword','forgotusername','setpassword']);
    }
    public function login()
    {

        $this->request->allowMethod(['get', 'post']);
        $result = $this->Authentication->getResult();

        $this->viewBuilder()->setLayout('landing');

        // regardless of POST or GET, redirect if user is logged in
        if ($result->isValid()) {
            

            // redirect to /pages/home after login success
            $redirect = $this->request->getQuery('redirect', [
                'controller' => 'users',
                'action' => 'menuadmin'
            ]);
            return $this->redirect($redirect);
        }
        // display error if user submitted and authentication failed
        if ($this->request->is('post') && !$result->isValid()) {

            $this->Flash->error(__('Invalid username or password'));
        }
    }
    public function logout()
    {
        $result = $this->Authentication->getResult();
        // regardless of POST or GET, redirect if user is logged in
        if ($result->isValid()) {
            $this->Authentication->logout();
            $session = $this->getRequest()->getSession();
            $session->delete('user');
            return $this->redirect(['controller' => 'Users', 'action' => 'login']);
        }
    }
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Roles'],
        ];
        $users = $this->paginate($this->Users);

        $this->set(compact('users'));
    }


    public function menuadmin()
    {
        $u = $this->Authentication->getResult()->getData();
        if($u->role_id==2)
            $this->viewBuilder()->setLayout('admin');
        else
        if($u->role_id==3 || $u->role_id==4)
          $this->viewBuilder()->setLayout('admin');
        else
        if($u->role_id==5){
            $this->viewBuilder()->setLayout('member');
        }
    }

    function forgotusername(){
        
        $this->request->allowMethod(['get', 'post']);
        

        $this->viewBuilder()->setLayout('landing');
        $result=null;
        // regardless of POST or GET, redirect if user is logged in
        
        if ($this->request->is('post')) {
            $mobile=$this->request->getData('mobile');
            $sponsor=$this->request->getData('sponsor');
            $type=$this->request->getData('type');

            if($type=='M'){
                $this->loadModel('Members');
                $result=$this->Members->find()->where(['mobile'=>$mobile,'sponsor'=>$sponsor])->first();
            }
            else
            if($type=='F')
            {
                $this->loadModel('Frenchies');
                $result=$this->Frenchies->find()->where(['mobile'=>$mobile,'sponsor'=>$sponsor])->first();
            }

            if(empty($result)){
                $this->Flash->error(__('Not Match'));

            }else{
                $this->Flash->success(__('Your User ID:'.$result['id']));
            }

            
        }
        

    }
    function forgotpassword(){
        $this->request->allowMethod(['get', 'post']);
        $session=$this->request->getSession();        

        $this->viewBuilder()->setLayout('landing');
        $result=null;
        // regardless of POST or GET, redirect if user is logged in
        
        if ($this->request->is('post')) {
           
            $username=$this->request->getData('username');
            $type=$this->request->getData('type');

            if($type=='M'){
                $this->loadModel('Members');
                $result=$this->Members->find()->where(['id'=>$username])->first();
            }
            else
            if($type=='F')
            {
                $this->loadModel('Frenchies');
                $result=$this->Frenchies->find()->where(['id'=>$username])->first();
            }

            if(empty($result)){
                $this->Flash->error(__('Invalid User Name'));

            }else{

                $otp=1234;
                $session->write('username',$username);
                $session->write('type',$type);
                $session->write('otp',$otp);
                $session->write('mobile',$result->mobile);

                //$this->forgotpassword1($type,$username,$result->mobile,$otp);
                $this->redirect('/setpassword');
                
            }

        }
    }

    function setpassword(){
        $this->request->allowMethod(['get', 'post']);

        $session = $this->request->getSession();
        $username= $session->read('username');
        $type= $session->read('type');
        $otp=$session->read('otp');
        $mobile=$session->read('mobile');

        

        $this->viewBuilder()->setLayout('landing');
        $result=null;
        // regardless of POST or GET, redirect if user is logged in
        $error=false;
        if ($this->request->is('post')) {


            $v_otp=$this->request->getData('otp');
            $password=$this->request->getData('password');
            $repassword=$this->request->getData('repassword');

            if($password!=$repassword && !$error) {
                    $this->Flash->error(__('New Password not match with confirm Password'));
                    $error=true;
                }

            if($v_otp!=$otp && !$error){
                $this->Flash->error(__('Invalid OTP,Please try again'));
                $error=true;
            }

            if(!$error){
                
                $user=$this->Users->find()->where(['username'=>$username])->first();

                $user['password']=$password;

                if($this->Users->save($user)){
        $session->delete('username');
        $session->delete('type');
        $session->delete('otp');
        $session->delete('mobile');

                $this->Flash->success(__('Password changed successfuly'));
                //$this->redirect(['controller'=>'pages','action'=>'confirm']);
                $this->redirect('confirm');
                }else
                {
                    $this->Flash->error(__('Some Error occured,Please try again'));
                }

            }

            
        }else{
            
            
 
        }

        $mobile=str_repeat("*" ,strlen($mobile)-4) . substr($mobile,-4);
        $this->set(compact('username','type','mobile'));

        }

}