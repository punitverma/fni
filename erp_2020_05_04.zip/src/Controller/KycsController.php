<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Kycs Controller
 *
 * @property \App\Model\Table\KycsTable $Kycs
 *
 * @method \App\Model\Entity\Kyc[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class KycsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $this->viewBuilder()->setLayout('member');
        $u= $this->Authentication->getResult()->getData();
        $kyc= $this->Kycs->find('all')->where(['member_id'=>$u->username])->first();
        $kycdoc= null;
        if(empty($kyc)){
            $kyc = $this->Kycs->newEmptyEntity();
            $kyc->member_id=$u->username;
            $kyc->pan='';
            $kyc->ifsc='';
            $kyc->name='';
            $kyc->accno='';
            $this->Kycs->save($kyc);

        }else{
            $kycdoc=$this->Kycs->Kycdocs->find()->where(['kyc_id'=>$kyc->id])->first();
        }
        
        if ($this->request->is(['post','put']) && $kyc->approveby==null && $kyc->approveon==null) { // 
            
            $kyc = $this->Kycs->patchEntity($kyc, $this->request->getData());
            $kyc->member_id=$u->username;
            $kyc->approveby=null;
            $kyc->approveon=null;

            
            if ($this->Kycs->save($kyc)) {
                $this->Flash->success(__('The kyc has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The kyc could not be saved. Please, try again.'));
        }
        $kyc['doc']=empty($kycdoc);
        $this->set(compact('kyc'));

    }   

    
    
}
