<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Item[]|\Cake\Collection\CollectionInterface $items
 */
?>
<div class="row">
    <div class="col-4">
    <div class="card">
    <div class="card-header info">
    Add/Edit/Save
  </div>
  <div class="card-body">
  <?= $this->Form->create($item) ?>
            <fieldset>
                
                <?php
                    echo $this->Form->control('id',['type'=>'hidden']);
                    echo $this->Form->control('frenchietype_id', ['label'=>'Type','options' => $frenchietypes,"empty"=>"select"]);
                ?>
                <?php if($this->Identity->get('role_id')==2) { ?>
                <span id="sponsor_lbl">_________</span>
          
                <?php
                    echo $this->Form->control('sponsor');
                }
                    echo $this->Form->control('name');
                    echo $this->Form->control('mobile');
                    echo $this->Form->control('address');
                    echo $this->Form->control('state_id', ['options' => $states]);
                    echo $this->Form->control('district_id', ['options' => $districts]);
                ?>
                
                
            </fieldset>
            <?= $this->Form->button(__('Save')) ?>
            <?= $this->Form->end() ?>

  </div>
    </div>
    </div>
    <div class="col-8">
    <div class="card">
    <div class="card-header info">
    List
  </div>
  <div class="card-body">
  <div class="items index content">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('frenchietype_id') ?></th>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('name') ?></th>
                    <th><?= $this->Paginator->sort('address') ?></th>
                    
                    <th><?= $this->Paginator->sort('state') ?></th>
                    <th><?= $this->Paginator->sort('district') ?></th>
                    <th><?= $this->Paginator->sort('mobile') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                <tr>
                    <th><?= h($item->frenchietype->name) ?></th>
                    <td><?= h($item->id)?></td>
                    <td><?= h($item->name)?></td>
                    <td><?= h($item->address) ?></td>
                    
                    <td><?= h($item->state->name) ?></td>
                    <td><?= h($item->district->name) ?></td>
                    <td><?= h($item->mobile) ?></td>
                    <td class="actions">
                        
                        <?= $this->Html->link(__('Edit'), ['action' => 'index', $item->id]) ?>
                        <!--<?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $item->id], ['confirm' => __('Are you sure you want to delete # {0}?', $item->id)]) ?>-->
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
</div>
  </div>
    </div>
</div>
<script>
$(function(){

  $('#frenchietype-id').on('change', function() {
      if($(this).val()==1){
          $("#sponsor").val('');
          $("#sponsor").prop('readonly',true);
          $('#sponsor_lbl').html('');
      }else{
        $("#sponsor").prop('readonly',false);
      }

  });  
  $('#state-id').on('change', function() {

    var id = $(this).val();
    
    var targeturl = '/districts';
    if(id == '0'){
      $('#district-id').html(`<option value="-1">Select State</option>`);
    }else{
      
	    $('#district-id').html(`<option value="-1">Select State</option>`); 	
		  $.ajax({
              type:'get',
              url: targeturl+"/"+id,                  
			  //data:'id='+id+'&type=state',
			  dataType: 'json',
			  success:function(result){
				  // $("#divLoading").removeClass('show');
				  $.each(result.result, function (key, data) {
                    $('#district-id').append('<option value="'+ key +'">'+ data+'</option>');
                  });
                   

			  }
		  });	
	  }
	});

    $('#sponsor').on('blur', function() {

    var id = $(this).val();
    var lb=$('#sponsor_lbl');
    if(id.length>10){
        var targeturl = '/findfrenchie';
        $.ajax({
          type:'get',
          url: targeturl+"/"+id,                  
          //data:'id='+id+'&type=state',
          dataType: 'json',
          success:function(data){
            if(data['result'][0]==null)
                lb.html("Sponser Id : "+"<span color='blue'>"+ "Not Match" +"</span>")
            else
                lb.html("Sponser Name : "+"<span color='blue'>"+ data['result'][0]['name'] +"</span>")
              
               

          }
      });	


    }



  
});

});
</script>