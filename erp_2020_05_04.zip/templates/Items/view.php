<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Item $item
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Item'), ['action' => 'edit', $item->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Item'), ['action' => 'delete', $item->id], ['confirm' => __('Are you sure you want to delete # {0}?', $item->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Items'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Item'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="items view content">
            <h3><?= h($item->name) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($item->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Description') ?></th>
                    <td><?= h($item->description) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($item->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Mrp') ?></th>
                    <td><?= $this->Number->format($item->mrp) ?></td>
                </tr>
                <tr>
                    <th><?= __('Saleprice') ?></th>
                    <td><?= $this->Number->format($item->saleprice) ?></td>
                </tr>
                <tr>
                    <th><?= __('Purchaseprice') ?></th>
                    <td><?= $this->Number->format($item->purchaseprice) ?></td>
                </tr>
                <tr>
                    <th><?= __('Points') ?></th>
                    <td><?= $this->Number->format($item->points) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Invoicedetails') ?></h4>
                <?php if (!empty($item->invoicedetails)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Invoice Id') ?></th>
                            <th><?= __('Item Id') ?></th>
                            <th><?= __('Itemname') ?></th>
                            <th><?= __('Price') ?></th>
                            <th><?= __('Points') ?></th>
                            <th><?= __('Qty') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($item->invoicedetails as $invoicedetails) : ?>
                        <tr>
                            <td><?= h($invoicedetails->id) ?></td>
                            <td><?= h($invoicedetails->invoice_id) ?></td>
                            <td><?= h($invoicedetails->item_id) ?></td>
                            <td><?= h($invoicedetails->itemname) ?></td>
                            <td><?= h($invoicedetails->price) ?></td>
                            <td><?= h($invoicedetails->points) ?></td>
                            <td><?= h($invoicedetails->qty) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Invoicedetails', 'action' => 'view', $invoicedetails->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Invoicedetails', 'action' => 'edit', $invoicedetails->id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'Invoicedetails', 'action' => 'delete', $invoicedetails->id], ['confirm' => __('Are you sure you want to delete # {0}?', $invoicedetails->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Stocks') ?></h4>
                <?php if (!empty($item->stocks)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Frenchie Id') ?></th>
                            <th><?= __('Item Id') ?></th>
                            <th><?= __('Qty') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($item->stocks as $stocks) : ?>
                        <tr>
                            <td><?= h($stocks->id) ?></td>
                            <td><?= h($stocks->frenchie_id) ?></td>
                            <td><?= h($stocks->item_id) ?></td>
                            <td><?= h($stocks->qty) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Stocks', 'action' => 'view', $stocks->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Stocks', 'action' => 'edit', $stocks->id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'Stocks', 'action' => 'delete', $stocks->id], ['confirm' => __('Are you sure you want to delete # {0}?', $stocks->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
