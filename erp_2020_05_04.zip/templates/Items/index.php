<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Item[]|\Cake\Collection\CollectionInterface $items
 */
?>
<div class="row">
    <div class="col-4">
    <div class="card">
    <div class="card-header info">
    Item Master 
  </div>
  <div class="card-body">
  <?= $this->Form->create($item) ?>
            <fieldset>
                
                <?php
                    echo $this->Form->control('id',['type'=>'hidden']);
                    echo $this->Form->control('name');
                    echo $this->Form->control('hsn',['label'=>'HSN Code']);
                    echo $this->Form->control('itemcat_id',['label'=>'CATEGORY','options'=>$itemcats]);
                    
                    echo $this->Form->control('purchaseprice',['label'=>'PURCHASE PRICE']);
                    echo $this->Form->control('saleprice',['label'=>'SALE PRICE']);
                    
                    echo $this->Form->control('points',['label'=>'Point (BV)']);
                    echo $this->Form->control('tax',['label'=>'GST Tax %']);
                    echo $this->Form->control('dp',['label'=>'DP']);
                    echo $this->Form->control('mrp',['label'=>'MRP']);
                    echo $this->Form->control('description');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Save')) ?>
            <?= $this->Form->end() ?>

  </div>
    </div>
    </div>
    <div class="col-8">
    <div class="card">
    <div class="card-header info">
    List
  </div>
  <div class="card-body">
  <div class="items index content">
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    
                    <th><?= $this->Paginator->sort('name') ?></th>
                    <th><?= $this->Paginator->sort('hsn') ?></th>
                    <th><?= $this->Paginator->sort('description') ?></th>
                    <th><?= $this->Paginator->sort('mrp') ?></th>
                    <th><?= $this->Paginator->sort('saleprice') ?></th>
                    <th><?= $this->Paginator->sort('purchaseprice') ?></th>
                    <th><?= $this->Paginator->sort('points') ?></th>
                    <th><?= $this->Paginator->sort('tax') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                <tr>
                    
                    <td><?= h($item->name) ?></td>
                    <td><?= h($item->hsn) ?></td>
                    <td><?= h($item->description) ?></td>
                    <td><?= $this->Number->format($item->mrp) ?></td>
                    <td><?= $this->Number->format($item->saleprice) ?></td>
                    <td><?= $this->Number->format($item->purchaseprice) ?></td>
                    <td><?= $this->Number->format($item->points) ?></td>
                    <td><?= $this->Number->format($item->tax) ?></td>
                    <td class="actions">
                        
                        <?= $this->Html->link(__('Edit'), ['action' => 'index', $item->id]) ?>
                        <!--<?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $item->id], ['confirm' => __('Are you sure you want to delete # {0}?', $item->id)]) ?>-->
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
</div>
  </div>
    </div>
</div>
