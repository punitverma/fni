<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Member $member
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Member'), ['action' => 'edit', $member->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Member'), ['action' => 'delete', $member->id], ['confirm' => __('Are you sure you want to delete # {0}?', $member->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Members'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Member'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="members view content">
            <h3><?= h($member->name) ?></h3>
            <table>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= h($member->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Membertype') ?></th>
                    <td><?= $member->has('membertype') ? $this->Html->link($member->membertype->name, ['controller' => 'Membertypes', 'action' => 'view', $member->membertype->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Sponsor') ?></th>
                    <td><?= h($member->sponsor) ?></td>
                </tr>
                <tr>
                    <th><?= __('Parent') ?></th>
                    <td><?= h($member->parent) ?></td>
                </tr>
                <tr>
                    <th><?= __('Placement') ?></th>
                    <td><?= h($member->placement) ?></td>
                </tr>
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($member->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Adddetails') ?></th>
                    <td><?= h($member->adddetails) ?></td>
                </tr>
                <tr>
                    <th><?= __('Mobile') ?></th>
                    <td><?= h($member->mobile) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email') ?></th>
                    <td><?= h($member->email) ?></td>
                </tr>
                <tr>
                    <th><?= __('Address') ?></th>
                    <td><?= $member->has('address') ? $this->Html->link($member->address->id, ['controller' => 'Addresses', 'action' => 'view', $member->address->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Kyc') ?></th>
                    <td><?= h($member->kyc) ?></td>
                </tr>
                <tr>
                    <th><?= __('Active') ?></th>
                    <td><?= h($member->active) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Kycs') ?></h4>
                <?php if (!empty($member->kycs)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Member Id') ?></th>
                            <th><?= __('Pan') ?></th>
                            <th><?= __('Ifsc') ?></th>
                            <th><?= __('Name') ?></th>
                            <th><?= __('Accno') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($member->kycs as $kycs) : ?>
                        <tr>
                            <td><?= h($kycs->id) ?></td>
                            <td><?= h($kycs->member_id) ?></td>
                            <td><?= h($kycs->pan) ?></td>
                            <td><?= h($kycs->ifsc) ?></td>
                            <td><?= h($kycs->name) ?></td>
                            <td><?= h($kycs->accno) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Kycs', 'action' => 'view', $kycs->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Kycs', 'action' => 'edit', $kycs->id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'Kycs', 'action' => 'delete', $kycs->id], ['confirm' => __('Are you sure you want to delete # {0}?', $kycs->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Ledgers') ?></h4>
                <?php if (!empty($member->ledgers)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Member Id') ?></th>
                            <th><?= __('Date') ?></th>
                            <th><?= __('Fromleft') ?></th>
                            <th><?= __('Fromright') ?></th>
                            <th><?= __('Redeem') ?></th>
                            <th><?= __('Balance') ?></th>
                            <th><?= __('Dt') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($member->ledgers as $ledgers) : ?>
                        <tr>
                            <td><?= h($ledgers->id) ?></td>
                            <td><?= h($ledgers->member_id) ?></td>
                            <td><?= h($ledgers->date) ?></td>
                            <td><?= h($ledgers->fromleft) ?></td>
                            <td><?= h($ledgers->fromright) ?></td>
                            <td><?= h($ledgers->redeem) ?></td>
                            <td><?= h($ledgers->balance) ?></td>
                            <td><?= h($ledgers->dt) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Ledgers', 'action' => 'view', $ledgers->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Ledgers', 'action' => 'edit', $ledgers->id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'Ledgers', 'action' => 'delete', $ledgers->id], ['confirm' => __('Are you sure you want to delete # {0}?', $ledgers->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <div class="related">
                <h4><?= __('Related Transcations') ?></h4>
                <?php if (!empty($member->transcations)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Member Id') ?></th>
                            <th><?= __('Dt') ?></th>
                            <th><?= __('From Memeber') ?></th>
                            <th><?= __('Placement') ?></th>
                            <th><?= __('Points') ?></th>
                            <th><?= __('Invoice Id') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($member->transcations as $transcations) : ?>
                        <tr>
                            <td><?= h($transcations->id) ?></td>
                            <td><?= h($transcations->member_id) ?></td>
                            <td><?= h($transcations->dt) ?></td>
                            <td><?= h($transcations->from_memeber) ?></td>
                            <td><?= h($transcations->placement) ?></td>
                            <td><?= h($transcations->points) ?></td>
                            <td><?= h($transcations->invoice_id) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Transcations', 'action' => 'view', $transcations->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Transcations', 'action' => 'edit', $transcations->id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'Transcations', 'action' => 'delete', $transcations->id], ['confirm' => __('Are you sure you want to delete # {0}?', $transcations->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
