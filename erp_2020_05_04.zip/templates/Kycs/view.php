<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Kyc $kyc
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Kyc'), ['action' => 'edit', $kyc->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Kyc'), ['action' => 'delete', $kyc->id], ['confirm' => __('Are you sure you want to delete # {0}?', $kyc->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Kycs'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Kyc'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="kycs view content">
            <h3><?= h($kyc->name) ?></h3>
            <table>
                <tr>
                    <th><?= __('Member') ?></th>
                    <td><?= $kyc->has('member') ? $this->Html->link($kyc->member->name, ['controller' => 'Members', 'action' => 'view', $kyc->member->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Pan') ?></th>
                    <td><?= h($kyc->pan) ?></td>
                </tr>
                <tr>
                    <th><?= __('Ifsc') ?></th>
                    <td><?= h($kyc->ifsc) ?></td>
                </tr>
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($kyc->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Accno') ?></th>
                    <td><?= h($kyc->accno) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($kyc->id) ?></td>
                </tr>
            </table>
            <div class="related">
                <h4><?= __('Related Kycdocs') ?></h4>
                <?php if (!empty($kyc->kycdocs)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Kyc Id') ?></th>
                            <th><?= __('File') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($kyc->kycdocs as $kycdocs) : ?>
                        <tr>
                            <td><?= h($kycdocs->id) ?></td>
                            <td><?= h($kycdocs->kyc_id) ?></td>
                            <td><?= h($kycdocs->file) ?></td>
                            <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Kycdocs', 'action' => 'view', $kycdocs->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Kycdocs', 'action' => 'edit', $kycdocs->id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'Kycdocs', 'action' => 'delete', $kycdocs->id], ['confirm' => __('Are you sure you want to delete # {0}?', $kycdocs->id)]) ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
