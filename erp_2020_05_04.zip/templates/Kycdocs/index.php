<!--Main layout-->
<main>
    <div class="container">

        <!--Section: Main info-->
        <section class="mt-5 pt-5 wow">
            <div class="row">
                <div class="col-md-12 col-xl-10 col-sm-12 mb-4 mt-5">

                    <div class="card">
                        <div class="card-header info">
                            Document for KYC (Know Your Customer)
                        </div>
                        <div class="card-body">
                        <?= $this->Form->create($kycdoc,['type' => 'file','method'=>'post']) ?>
                            <div class="col-md-10 col-sm-12">
                                <div class="md-form">
                                <?php echo $this->Form->input('file', ['type' => 'file', 'class' => 'form-control']); ?>

                                </div>
                            </div>
                            
                            
                        </div>
                        <div class="col-md-6 col-sm-10">
                        <?php if($kyc->approveby==null && $kyc->approveon==null){ ?>
                        <?= $this->Form->button(__('Submit'),['id'=>'btnSave','class' => 'form-control primary','disabled'=>false]) ?>
                        <?php } ?>
                        </div>
                        <?= $this->Form->end() ?>
                    </div>
                </div>

            </div>

        </section>
    </div>
</main>
